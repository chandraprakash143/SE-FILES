import java.io.Serializable;
public class Book implements Serializable{
       private String isbn, authorname,title;
       private double price;
       public Book(){
         isbn=null;
         title=null;
         authorname=null;
         price=0;
       }
       public Book(String isbn,String title,String authorname,double price){
           this.isbn=isbn;
           this.title=title;
           this.authorname=authorname;
           this.price=price;
       }
       @Override
       public String toString(){
           return "\n Title:"+title+"/nAuthor:"+authorname+"/n isbn:"+isbn ;
       }
}



