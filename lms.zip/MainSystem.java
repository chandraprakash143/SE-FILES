import java.util.Scanner;
import java.io.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
public class MainSystem{
    static String fileName=null;
    static Library lib=new Library();
    static Scanner in=new Scanner(System.in);
    static Boolean running=true;
    public static void main(String args[]){
        while(running){
            System.out.println("\nEnter 0 to  load a library "+
            "\n Enter 1 for save and quit"+
            "/nEnter 2 for list all books in library"+
            "/nEnter 3 to  add books in library");
            
            int answer=in.nextInt();
            switch(answer){
                case 0:
                     System.out.println("enter the filename to load");
                     loadScript(in.next()); 
                     break;
                case 1:
                     saveAndQuit();


                     break;

                case 2:
                      System.out.println(lib.toString());
                      break;
                case 3:
                       addBook();
                      
                    
                      break;






            }
        }
        System.exit(0);
    }
    
    private static void loadScript(String Name){
                     FileInputStream fis=null;
                     ObjectInputStream in=null;
                     File file=new File(fileName+".txt");
                     if(file.exists()){
                         try{
                              fis=new FileInputStream(file);
                              in=new ObjectInputStream(fis);
                              lib=(Library) in.readObject();
                              fis.close();
                              in.close();

                         } catch(IOException e){
                             e.printStackTrace();

                         }catch (ClassNotFoundException e){
                              e.printStackTrace();

                         }
                     }
                     else{
                         System.out.println("\n the file does not exist");
                           
                     }
    }
    private static void saveAndQuit(){
        System.out.println("Enter file name:");
        fileName=in.next() +".txt";
        running =false;
        FileOutputStream fos = null;
        ObjectOutputStream out= null;
        
        try{
                              fos=new FileOutputStream(fileName);
                              out=new ObjectOutputStream(fos);
                              out.writeObject(lib);
                              fos.close();
                              out.close();

                         } catch(IOException e){
                             e.printStackTrace();

                         }/*catch (ClassNotFoundException e){
                              e.printStackTrace();

                         }*/
                         
                         

    }
    private static void addBook(){
        String isbn, authorname,title;
        double price;
        System.out.println("/n Enter title:");
        title= in.next(); 
        System.out.println("/n Enter authorname:");
        authorname= in.next(); 
        System.out.println("/n Enter isbn:");
        isbn= in.next(); 
        System.out.println("/n Enter price:");
        price= in.nextDouble(); 
        Book b=new Book(isbn,title,authorname,price);
        lib.addBook(b);

       
    }


    }
